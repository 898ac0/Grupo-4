from collections import namedtuple
from django.urls import path
from .views import index
from .views import contacto
from .views import obras
from .views import api
from .views import buscador
from .views import modificar 
from .views import eliminar  


urlpatterns  = [
    path('',index, name='index'),
    path('contacto/',contacto, name='contacto'),
    path('obras/',obras, name='obras'),
    path('api/',api, name='api'),
    path('buscador/',buscador, name='buscador'),
    path('modificar/<id>',modificar, name='modificar'),
    path('eliminar/<id>',eliminar, name='eliminar')
]