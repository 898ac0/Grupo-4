from django.db import models

# Clase Formulario

class Formulario(models.Model):
    idFormulario = models.IntegerField(primary_key=True, verbose_name='Id Formulario')
    nombre = models.CharField(max_length=50, verbose_name='Nombre')
    apellidos = models.CharField(max_length=100, verbose_name='Apellidos')
    email = models.CharField(max_length=50, verbose_name='Correo')
    telefono = models.IntegerField(verbose_name='Teléfono')

    def __str__(self):
        return self.nombre

    

class Obra(models.Model):
    idObra = models.IntegerField(primary_key=True, verbose_name='Id Obras')
    nombre_obra = models.CharField(max_length=100, verbose_name='Nombre de la Obra')
    autor_obra = models.CharField(max_length=100, null=True, verbose_name='Autor')
    precio = models.IntegerField(verbose_name='Valor de la Obra')

    def __str__(self):
        return self.nombre_obra