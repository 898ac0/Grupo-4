from core.forms import ObraForm
from django.shortcuts import redirect, render
from .models import Obra
from .models import Formulario
# Create your views here.

def index(request):
    return render(request, 'core/index.html')

def contacto(request):
    return render(request, 'core/contacto.html')

def obras(request):
    datos = {
        'form': ObraForm()
      }
    if request.method == 'POST':
        formulario = ObraForm(request.POST)

        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = "Obra Subida Correctamente"
    return render(request, 'core/obras.html', datos)

   
def api(request):
    return render(request, 'core/api.html')

def buscador(request):
    obras= Obra.objects.all()
    datos = {
        'obras' : obras
    }

    return render (request, 'core/buscador.html',datos)

def modificar(request,id):

    obra = Obra.objects.get(idObra=id)

    datos = {
        'form' : ObraForm(instance=obra)
    }

    if request.method == 'POST':

        formulario = ObraForm(data=request.POST,instance=obra)

        if formulario.is_valid:
            formulario.save()
            datos['mensaje'] = "Datos modificados correctamente"

    return render (request, 'core/modificar.html', datos)

def eliminar(request,id):

    obra = Obra.objects.get(idObra=id)
    obra.delete()

    return redirect(to="buscador")