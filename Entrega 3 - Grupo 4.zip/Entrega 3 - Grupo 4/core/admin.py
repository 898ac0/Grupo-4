from django.contrib import admin
from .models import Formulario, Obra
# Register your models here.
admin.site.register(Formulario)
admin.site.register(Obra)



