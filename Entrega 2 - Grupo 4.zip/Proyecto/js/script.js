$(document).ready(function(){


    
    $("#error").hide();

    $("#formulario").submit(function(){
        var mensaje = "";


        if($("#nombre").val().trim().length==0){
            mensaje = "El campo nombre está en blanco";
    
        }

        if($("#apellidos").val().trim().length==0){
            mensaje = "El campo apellidos está en blanco";
    
        }
        

        if($("#email").val().trim().length==0){
            mensaje = "El campo email está en blanco";
        }
        
        if($("#telefono").val().trim().length==0){
            mensaje = "El campo número telefónico está en blanco";
        }

        telefono = document.getElementById("telefono").value;
            if( !(/^\d{9}$/.test(telefono)) ) {
                mensaje = "El número de teléfono debe estar en el formato correcto";
            }

        

        if (mensaje !="")
        {
            $("#error").html(mensaje);
            $("#error").show();
            event.preventDefault();

        }

    });

});




